<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create service</title>

    <?php include('css.php'); ?>
</head>

<body>

    <?php include('header.php'); ?>
    <?php include('navbar.php'); ?>

    <?php
    error_reporting(1);
    include("connection.php");
    $title = $_POST['title'];
    $image = $_FILES['image']['name'];
    $description = $_POST['description'];
    $submit = $_POST['submit'];
    if (isset($submit)) {
        move_uploaded_file($_FILES['image']['tmp_name'], 'image/' . $image);
        $data = "INSERT INTO service(title,image,description)VALUES('$title','$image','$description')";
        $connection->query($data);
        header('location:about.php');
    }

    ?>

    <!-- register form start  -->

    <div class="register-form">
        <form method="POST" enctype="multipart/form-data">
            <h3>Create Service Form</h3>
            <input type="text" name="title" placeholder="Enter your title name" class="box" required>
            <input type="file" name="image" class="box" required>
            <textarea type="text" name="description" placeholder="enter your description" class="box" style="height: 150px;" id="service_description"></textarea>
            <input type="submit" name="submit" value="Create Now" class="btn">
        </form>
    </div>

    <!-- register form end  -->

    <?php include('footer.php'); ?>
    <?php include('js.php'); ?>

</body>

</html>