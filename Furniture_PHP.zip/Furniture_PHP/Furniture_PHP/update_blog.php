<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Blog</title>

    <?php include('css.php'); ?>
</head>

<body>

    <?php include('header.php'); ?>
    <?php include('navbar.php'); ?>


    <?php
    error_reporting(1);
    include("connection.php");
    $id = $_GET['id'];
    $old_data = "SELECT * FROM blog WHERE id=$id";
    $rawdata = $connection->query($old_data,);
    $result = mysqli_fetch_array($rawdata);

    $name = $_POST['name'];
    $image = $_FILES['image'];
    $description = $_POST['description'];
    $creator = $_POST['creator'];
    $submit = $_POST['submit'];

    $old_image = $result['image'];
    $new_image = $_FILES['image']['name'];

    if (isset($submit)) {
        if ($new_image) {
            $image = $new_image;
            move_uploaded_file($_FILES['image']['tmp_name'], 'image/' . $image);
            if (file_exists('image/.$old_image')) {
                unlink('image/' . $old_image);
            }
        } else {
            $image = $old_image;
        }
        $data = "UPDATE blog SET name='$name',image='$image',description='$description',creator='$creator' WHERE id=$id";
        $connection->query($data);
        header('location:blog.php');
    }
    ?>

    <div class="register-form">
        <form method="POST" enctype="multipart/form-data">
            <h3>Update Blog Form</h3>
            <input type="text" name="name" value="<?php echo $result['name'] ?>" placeholder="Enter your product name" class="box" required>
            <input type="file" name="image" value="<?php echo $result['image'] ?>" class="box" required>
            <textarea
                class="form-control"
                name="description"
                id="pruduct_description"
                rows="3"
                placeholder="Enter your description"
                style="width: 100%; padding: 10px; border-radius: 6px; border: 1px solid #d8bfbf; background-color: #f2e6e3; font-size: 14px; color: #4d4d4d;" value="<?php echo $result['description'] ?>"></textarea>
            <input type="submit" name="submit" value="Create Now" class="btn">
        </form>
    </div>



    <?php include('footer.php'); ?>
    <?php include('js.php'); ?>

</body>

</html>