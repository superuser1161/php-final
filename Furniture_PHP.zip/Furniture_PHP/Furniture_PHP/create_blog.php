<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog Create</title>

    <?php include('css.php'); ?>
</head>

<body>

    <?php include('header.php'); ?>
    <?php include('navbar.php'); ?>

    <!-- register form start  -->


    <?php
    error_reporting(1);
    include("connection.php");
    $name = $_POST['name'];
    $image = $_FILES['image']['name'];
    $description = $_POST['description'];
    $creator = $_POST['creator'];
    $submit = $_POST['submit'];
    if (isset($submit)) {
        move_uploaded_file($_FILES['image']['tmp_name'], 'image/' . $image);
        $data = "INSERT INTO blog(name,image,description,creator)VALUES('$name','$image','$description','$creator')";
        $connection->query($data);
        header('location:blog.php');
    }

    ?>

    <div class="register-form">
        <form method="POST" enctype="multipart/form-data">
            <h3>Blog Create Form</h3>

            <input type="text" name="name" placeholder="Enter your product name" class="box" required>
            <input type="file" name="image" class="box" required>
            <input type="text" name="creator" placeholder="Enter your name" class="box" required>
            <textarea
                class="form-control"
                name="description"
                id="pruduct_description"
                rows="3"
                placeholder="Enter your description"
                style="width: 100%; padding: 10px; border-radius: 6px; border: 1px solid #d8bfbf; background-color: #f2e6e3; font-size: 14px; color: #4d4d4d;"></textarea>
            <input type="submit" name="submit" value="Create Now" class="btn">
        </form>
    </div>

    <!-- register form end  -->

    <?php include('footer.php'); ?>
    <?php include('js.php'); ?>

</body>

</html>