<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Product</title>

    <?php include('css.php'); ?>
</head>

<body>

    <?php include('header.php'); ?>
    <?php include('navbar.php'); ?>


    <?php
    error_reporting(1);
    include("connection.php");
    $id = $_GET['id'];
    $old_data = "SELECT * FROM product WHERE id=$id";
    $rawdata = $connection->query($old_data,);
    $result = mysqli_fetch_array($rawdata);

    $name = $_POST['name'];
    $price = $_POST['price'];
    $image = $_FILES['image'];
    $quantity = $_POST['quantity'];
    $submit = $_POST['submit'];

    $old_image = $result['image'];
    $new_image = $_FILES['image']['name'];

    if (isset($submit)) {
        if ($new_image) {
            $image = $new_image;
            move_uploaded_file($_FILES['image']['tmp_name'], 'image/' . $image);
            if (file_exists('image/.$old_image')) {
                unlink('image/' . $old_image);
            }
        } else {
            $image = $old_image;
        }
        $data = "UPDATE product SET name='$name',price='$price',image='$image',quantity='$quantity' WHERE id=$id";
        $connection->query($data);
        header('location:shop.php');
    }
    ?>

    <div class="register-form">
        <form method="POST" enctype="multipart/form-data">
            <h3>Update Product Form</h3>
            <input type="text" name="name" value="<?php echo $result['name'] ?>" placeholder="Enter your product name" class="box" required>
            <input type="file" name="image" value="<?php echo $result['image'] ?>" class="box" required>
            <input type="number" name="price" value="<?php echo $result['price'] ?>" class="box" required>
            <input type="number" name="quantity" value="<?php echo $result['quantity'] ?>" class="box" required>
            <input type="submit" name="submit" value="Create Now" class="btn">
        </form>
    </div>



    <?php include('footer.php'); ?>
    <?php include('js.php'); ?>

</body>

</html>