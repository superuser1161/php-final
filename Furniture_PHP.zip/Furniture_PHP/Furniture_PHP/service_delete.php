<?php

include("connection.php");
$id = $_GET['id'];
$image = $_GET['image'];
$data = "DELETE FROM service WHERE id=$id";
if (file_exists('image/' . $image)) {
    unlink('image/' . $image);
}
$connection->query($data);
header('location:about.php');
?>